Design an alarm system for a driverless car  
