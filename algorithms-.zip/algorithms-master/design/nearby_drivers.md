Design the backend architecture to show nearby drivers
