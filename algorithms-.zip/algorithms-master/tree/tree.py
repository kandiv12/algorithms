class TreeNode:
    def __init__(self, val=0):
        self.val = val
        self.left = None
        self.right = None



